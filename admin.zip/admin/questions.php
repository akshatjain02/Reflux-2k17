<?php
   include("session.php");
?>

<?php 
	


   	$dbhost = "mysql.hostinger.in";
	$dbuser = "u932729557_admin";
	$dbpass = "Aks12345";
	$dbname = "u932729557_main";

   $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   
   if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
  

?>	

<html>
<head>
   <title>Reflux | Quiz</title>
</head>
<body>

       
<?php 

if($_SERVER['REQUEST_METHOD']=="POST"){

    $question = $_POST['question'];
            $answer = $_POST['answer'];
            $level = $_POST['level'];

            $option1 = $_POST['option1'];
            $option2 = $_POST['option2'];
            $option3 = $_POST['option3'];
            $option4 = $_POST['option4'];

            $id = $_POST['id'];

            $sql = 'UPDATE quiz_questions SET question = "'.$question.'", answer = "'.$answer.'", level = "'.$level.'", option1 = "'.$option1.'", option2 = "'.$option2.'", option3 = "'.$option3.'", option4 = "'.$option4.'", answer = "'.$answer.'", proofread = "1" WHERE id = "'.$id.'"';

            // $sql = 'INSERT INTO quiz_questions '.'(question, answer, level,option1, option2, option3, option4) '.'VALUES ("' . $question . '","' . $answer . '","' . $level . '","' . $option1 . '","'  . $option2 . '","' . $option3 . '","' . $option4  .'")';
                

if ($conn->query($sql) === TRUE) {
                    $msg = "New record created successfully";
            }else {
                $msg = "Error: " . $sql . "<br>" . $conn->error;
            }
                $conn->close();

            header("Location:proofread.php");
            exit();
}
else{

$id = $_GET['num'];
   $sql = 'SELECT * FROM quiz_questions WHERE id ='.$id;
   $retval = $conn->query($sql);
if($_GET['v']=="edit")
{
if ($retval->num_rows > 0) {
    while($row = $retval->fetch_assoc()) {


      $question = $_POST['question'];
      $answer = $_POST['answer'];
      $option1 = $_POST['option1'];
      $option2 = $_POST['option2'];
      $option3 = $_POST['option3'];
      $option4 = $_POST['option4'];
      $level = $_POST['level'];

        echo <<<EOL
        <center>
<h2>Enter Question</h2>
<h4>*Please enter the questions carefully</h4></center>
    <form action="" method="post">
        <label for="question">Question</label><br>
       <textarea id="question" name="question" value="$question" required autofocus style="width:100%;height:100px;"></textarea><br/><br/>

       <label for="answer">Answer</label><br>
       <input id="answer" type="text" name="answer" value="$answer" required  /><br/><br/>

    <label for="answer">Option1</label><br>
       <input id="option1" type="text" name="option1"  value="$option1" required  /><br/><br/>

    <label for="answer">Option2</label><br>
       <input id="option2" type="text" name="option2" value="$option2" required  /><br/><br/>

    <label for="answer">Option3</label><br>
       <input id="option3" type="text" name="option3" value="$option3" required  /><br/><br/>

    <label for="answer">Option4</label><br>
       <input id="option4" type="text" name="option4" value="$option4" required  /><br/><br/>

       <label for="level">Level</label>
       <select name="level" id="level" default="$level" required>
          <option value="1">Easy</option>
          <option value="2">Medium</option>
          <option value="3">Hard</option>
       </select><br/><br/>
       <h4 style="color:#552222"><?php echo $msg;  ?></h4>
       <input type="submit" name="submit" value="Submit" />
       </form>  
        
EOL;        
    }
} else {
    echo "0 results found";
}
}else if($_GET['v']=="view")
{
  if ($retval->num_rows > 0) {
    while($row = $retval->fetch_assoc()) {


      $question = $_POST['question'];
      $answer = $_POST['answer'];
      $option1 = $_POST['option1'];
      $option2 = $_POST['option2'];
      $option3 = $_POST['option3'];
      $option4 = $_POST['option4'];
      $level = $_POST['level'];

        echo <<<EOL
        <center>
<h2>Enter Question</h2>
<h4>*Please enter the questions carefully</h4></center>
    <form action="" method="post">
        <label for="question">Question</label><br>
       <textarea disabled id="question" name="question" value="$question" required autofocus style="width:100%;height:100px;"></textarea><br/><br/>

       <label for="answer">Answer</label><br>
       <input disabled id="answer" type="text" name="answer" value="$answer" required  /><br/><br/>

    <label for="answer">Option1</label><br>
       <input disabled id="option1" type="text" name="option1"  value="$option1" required  /><br/><br/>

    <label for="answer">Option2</label><br>
       <input disabled id="option2" type="text" name="option2" value="$option2" required  /><br/><br/>

    <label for="answer">Option3</label><br>
       <input disabled id="option3" type="text" name="option3" value="$option3" required  /><br/><br/>

    <label for="answer">Option4</label><br>
       <input disabled id="option4" type="text" name="option4" value="$option4" required  /><br/><br/>

       <label for="level">Level</label>
       <select disabled name="level" id="level" default="$level" required>
          <option value="1">Easy</option>
          <option value="2">Medium</option>
          <option value="3">Hard</option>
       </select><br/><br/>
       <h4 style="color:#552222"><?php echo $msg;  ?></h4>
       </form> 
        
EOL;        
    }
} else {
    echo "0 results found";
}
       
}
 }     
          
          $conn->close();

       ?>



</body>
</html>

