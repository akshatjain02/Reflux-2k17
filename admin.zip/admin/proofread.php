<?php
   include("session.php");
?>

<?php 
	
   	$dbhost = "mysql.hostinger.in";
	$dbuser = "u932729557_admin";
	$dbpass = "Aks12345";
	$dbname = "u932729557_main";

   $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   
   if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
  

   $sql = 'SELECT id FROM quiz_questions WHERE proofread = 0';
   
   $retval = $conn->query($sql);
      
  
if ($retval->num_rows > 0) {
    while($row = $retval->fetch_assoc()) {
        echo <<<EOL
        <a href="question.php?num=$row['id']&v=$row['edit']">$row['id']</a>&nbsp;&nbsp;&nbsp;&nbsp;
EOL;        
    }
} else {
    echo "0 results found";
}

$conn->close();

?>	