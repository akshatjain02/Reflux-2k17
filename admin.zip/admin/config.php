<?php
   define('DB_SERVER', 'mysql.hostinger.in');
   define('DB_USERNAME', 'u932729557_admin');
   define('DB_PASSWORD', 'Aks12345');
   define('DB_DATABASE', 'u932729557_main');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
